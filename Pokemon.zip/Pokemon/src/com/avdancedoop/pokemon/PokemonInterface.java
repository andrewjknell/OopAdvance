package com.avdancedoop.pokemon;

public interface PokemonInterface {

}
