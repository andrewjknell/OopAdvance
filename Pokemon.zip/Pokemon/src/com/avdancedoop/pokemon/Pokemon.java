package com.avdancedoop.pokemon;

public class Pokemon {

}
